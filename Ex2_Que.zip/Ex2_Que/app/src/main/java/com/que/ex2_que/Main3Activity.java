package com.que.ex2_que;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {
    EditText ets1;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        ets1 = findViewById(R.id.editText);

    }
    public void validateData(View v){
        sp = getSharedPreferences("data1", MODE_PRIVATE);
        String s1SP = sp.getString("s1", null);
        String s2SP = sp.getString("s2", null);
        String s3SP = sp.getString("s3", null);
        String s4SP = sp.getString("s4", null);
        String s5SP = sp.getString("s5", null);
        String s6SP = sp.getString("s6", null);
        String s7SP = sp.getString("s7", null);
        String s8SP = sp.getString("s8", null);
        String sc1 = ets1.getText().toString();

        if(s1SP.equalsIgnoreCase(sc1) || s2SP.equalsIgnoreCase(sc1) || s3SP.equalsIgnoreCase(sc1) || s4SP.equalsIgnoreCase(sc1) ||
                s5SP.equalsIgnoreCase(sc1) || s6SP.equalsIgnoreCase(sc1) || s7SP.equalsIgnoreCase(sc1) || s8SP.equalsIgnoreCase(sc1) ){
            Toast.makeText(this, "School is participating in UAAP", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, "School is not participating in UAAP", Toast.LENGTH_LONG).show();
        }
    }

}
